﻿using System;
{
    // Erstellen einer Instanz des Taschenrechners
    Taschenrechner rechner = new Taschenrechner();

    // Testfall für Addition
    double ergebnis = rechner.Addieren(128, 37);
    Console.WriteLine("Ergebnis der Addition: " + ergebnis); // Ausgabe: 12
    Console.WriteLine("Letztes addierte Ergebnis: " + rechner.LetztesErgebnis); // Ausgabe: 12

    // Testfall für Division
    ergebnis = rechner.Dividieren(29, 8);
    Console.WriteLine("Ergebnis der Division: " + ergebnis); // Ausgabe: 5
    Console.WriteLine("Letztes dividierte Ergebnis: " + rechner.LetztesErgebnis); // Ausgabe: 5

    // Testfall für Potenzierung
    ergebnis = rechner.Potenzieren(22, 13);
    Console.WriteLine("Ergebnis der Potenzierung: " + ergebnis); // Ausgabe: 8
    Console.WriteLine("Letztes potenzierte Ergebnis: " + rechner.LetztesErgebnis); // Ausgabe: 8

    // Testfall für Fakultät
    ergebnis = rechner.Fakultaet(5);
    Console.WriteLine("Ergebnis der Fakultät: " + ergebnis); // Ausgabe: 120
    Console.WriteLine("Letztes berechnete Fakultät: " + rechner.LetztesErgebnis); // Ausgabe: 120
}